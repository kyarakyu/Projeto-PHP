<?php

if(isset($_POST['submit']))
{
    //print_r('Nome: ' . $_POST['nome']);
    //print_r('<br>');
    //print_r('Email: ' . $_POST['email']);
    //print_r('<br>');
    //print_r('Telefone: ' . $_POST['telefone']);
    //print_r('<br>');

    include_once('config.php');
    
    $nome =  $_POST['nome'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    $telefone = $_POST['telefone'];

    $result = mysqli_query($conexao,"INSERT INTO `funcionarios`(`nome`, `email`, `senha`, `telefone`) VALUES ('$nome','$email','$senha','$telefone')");

    header('Location: login.php');
} 

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Formulario</title>
    <style>
        body{
            font-family: Arial, Helvetica, sans-serif;
            background-image:url(../img/sabonetes.png);
        }
        .box{
            color: #000;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: #E5DCDF;
            padding: 15px;
            border-radius: 15px;
            width: 30%;
        }
        fieldset{
            border: 3px solid #a77fa3;
        }
        legend{
            border: 1px solid #a77fa3;
            padding: 10px;
            text-align: center;
            background-color: #a77fa3;
            border-radius: 8px;
            color: white;
        }
        .inputBox{
            position: relative;
        }
        .inputUser{
            background: none;
            border: none;
            border-bottom: 1px solid black;
            outline: none;
            color: #000;
            font-size: 15px;
            width: 100%;
            letter-spacing: 2px; 
        }
        .labelInput{
            position: absolute;
            top: 0px;
            left: 0px;
            pointer-events: none;
            transform: .5px;
        }
        .inputUser:focus ~ .labelInput,
        .inputUser:valid ~ .labelInput{
            top: -20px;
            font-size: 12px;
            color: purple;
        }
        #data_nascimento{
            border: none;
            padding: 8px;
            border-radius: 10px;
            outline: none;
            font-size: 15px; 
        }
        #submit{
            background-color: #a77fa3;
            width: 100%;
            border: none;
            padding: 15px;
            color: white;
            font-size: 15px;
            cursor: pointer;
            border-radius: 10px;

        }
        #submit:hover{
            background-color: #BA55D3;
        }

        .a {
            padding: 7px 5px 10px 5px;
            width: 60px;
            height: 30px;
            color: white;
            background-color: #a77fa3;
            border-radius: 10px;
            border: none;
            text-decoration: none;
            cursor: pointer;
        }
    </style>
</head>
<body>
<form action="login.php" method="POST">
<input class="a"type="submit" name="submit" value="Voltar">
</form>
     
<div class="box">
    <form action="formulario.php" method="POST">
        <fieldset>
            <legend><b>Cadastro</b></legend>
            <br>
            <div class="inputBox">
                <input type="text" name="nome" id="nome" class="inputUser" required>
                <label for="nome" class="labelInput">Nome Completo</label>
            </div>
            <br><br>
            <div class="inputBox">
                <input type="email" name="email" id="email" class="inputUser" required>
                <label for="nome" class="labelInput">Email</label>
            </div>
            <br><br>
            <div class="inputBox">
                <input type="password" name="senha" id="senha" class="inputUser" required>
                <label for="senha" class="labelInput">Senha</label>
            </div>
            <br><br>
            <div class="inputBox">
                <input type="tel" name="telefone" id="telefone" class="inputUser" required>
                <label for="telefone" class="labelInput">Telefone</label>
            </div>
            
            <br><br>
            <input type="submit" name="submit" id="submit">
        </fieldset>
    </form>
</div>

</body>
</html>